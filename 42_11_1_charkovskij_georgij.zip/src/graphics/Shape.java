package graphics;

import java.awt.*;

class Shape {
    void draw(Graphics g, int size, int x, int y) {
        g.fillOval(x, y, size, size);
    }
}
