package client.ui;

import client.net.ConnectionManager;


import javax.swing.*;
import java.awt.*;
import java.io.IOException;


class WorkspacePanel extends JPanel {
    private FieldPanel fieldPanel;
    private int fieldWidth = 600, fieldHeight = 600;
    WorkspacePanel() {
        setDoubleBuffered(true);
        setBackground(Color.lightGray);
        setLayout(new FlowLayout());
        try {
            initField();
        } catch (IOException e) {
            e.printStackTrace();
        }

        SizePanel sizePanel = new SizePanel(20);
        sizePanel.setPreferredSize(new Dimension(200, 200));
        sizePanel.setBounds(0, 0, 200, 200);
        sizePanel.setFp(fieldPanel);


        ColorPanel colorPanel = new ColorPanel(0, 0, 0);
        colorPanel.setPreferredSize(new Dimension(200, 200));
        colorPanel.setBounds(0, 0, 200, 200);
        colorPanel.setFp(fieldPanel);

        fieldPanel.setPreferredSize(new Dimension(fieldWidth, fieldHeight));
        fieldPanel.setBounds(0, 0, fieldWidth, fieldHeight);

        add(fieldPanel);
        add(sizePanel);
        add(colorPanel);

    }

    public FieldPanel getFieldPanel() {
        return fieldPanel;
    }

    public void setConnectionManager(ConnectionManager connectionManager) {
        fieldPanel.setConnectionManager(connectionManager);
    }

    private void initField() throws IOException {
        fieldPanel = new FieldPanel(fieldWidth, fieldHeight); //создание нового поля с имеющмися параметрами
        fieldPanel.setDoubleBuffered(true); // защита от мерцания
    }
}
