package client.ui;

import javax.swing.*;
import java.awt.*;

public class FastSettingsPanel extends JPanel {
    protected FieldPanel fp;

    public FastSettingsPanel() {
        super();
        setOpaque(true);
        setBackground(Color.lightGray);
        setFocusable(false);
    }


}
