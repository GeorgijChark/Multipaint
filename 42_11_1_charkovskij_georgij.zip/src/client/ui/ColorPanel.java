package client.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;

public class ColorPanel extends FastSettingsPanel implements AdjustmentListener {
    public int VGAP = 30;
    Scrollbar redSlider, greenSlider, blueSlider;
    JLabel label;

    public ColorPanel() {
        super();
        redSlider = new Scrollbar(Scrollbar.HORIZONTAL, 1, 1, 0, 255);
        redSlider.setBounds(0, 0, 250, 20);

    }

    public ColorPanel(int r, int g, int b) {
        super();
        redSlider = new Scrollbar(Scrollbar.HORIZONTAL, r, 1, 0, 255);
        redSlider.setBounds(0, 0, 250, 20);

        greenSlider = new Scrollbar(Scrollbar.HORIZONTAL, g, 1, 0, 255);
        greenSlider.setBounds(0, 0, 250, 20);
        blueSlider = new Scrollbar(Scrollbar.HORIZONTAL, b, 1, 0, 255);
        blueSlider.setBounds(0, 0, 250, 20);

        redSlider.setFocusable(false);
        greenSlider.setFocusable(false);
        blueSlider.setFocusable(false);

        redSlider.addAdjustmentListener(this);
        greenSlider.addAdjustmentListener(this);
        blueSlider.addAdjustmentListener(this);

        redSlider.setBackground(new Color(redSlider.getValue(), 0, 0));
        greenSlider.setBackground(new Color(0, greenSlider.getValue(), 0));
        blueSlider.setBackground(new Color(0, 0, blueSlider.getValue()));

        setLayout(new GridLayout(3, 1, 0, VGAP));


        add(redSlider);
        add(greenSlider);
        add(blueSlider);

        setSize(200, 100);
        setBounds(0, 0, 200, 100);
    }

    public void setFp(FieldPanel fp) {
        this.fp = fp;
    }

    public Color getColor() {
        float[] color2 = Color.RGBtoHSB(redSlider.getValue(), greenSlider.getValue(), blueSlider.getValue(), null);
        Color color = Color.getHSBColor(color2[0], color2[1], color2[2]);
        return color;
    }

    @Override
    public void adjustmentValueChanged(AdjustmentEvent e) {
        fp.setPencilColor(getColor());
        repaint();
        getParent().repaint();
        redSlider.setBackground(new Color(redSlider.getValue(), 0, 0));
        greenSlider.setBackground(new Color(0, greenSlider.getValue(), 0));
        blueSlider.setBackground(new Color(0, 0, blueSlider.getValue()));

    }

}
